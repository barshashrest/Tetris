//class that controls the view of the game in command line
//TetrisBoardTextView creates a String view of a TetrisBoard.

public class TetrisGameTextView
{
    /**INSTANCE FIELDS**/
    //get the game
    private TetrisGame game;
    
    //Constructor
    //requires board to display
    public TetrisGameTextView (TetrisGame g)
    {
    }

    /**METHODS**/
    //method to get the board
    private String getBoardView()
    {
	//placeholder
	return ("x");
    }
    //method to get the current view as a String
    private String getView()
    {
	//placeholder
	return ("y");
    }


}
