//awt
import java.applet.Applet;

//applet that invokes the TetrisGame and the html file
public class TetrisGUIApplet extends Applet
{
    /**INSTANCE VARIABLES**/
    //has instance field of type Class TetrisGameGUIController that controls the update of the game
    private  TetrisGameGUIController	controller ;
    //special method that will be invoked when applet is created
public void start()
{

}
}
