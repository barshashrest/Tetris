import java.lang.Object;

//class that controls the command line version of the game
public class TetrisGameTextController
{

    /**INSTANCE FIELDS**/
    //field of type TetrisGame
    private TetrisGame game;

    //field that gets the tetris text view i.e that makes the command line game visible
    private TetrisGameTextView view;

    //Constructor
    public TetrisGameTextController() 
    {
    } 
    /**METHODS**/
    //main method to start the game
    public static void main(String[] args)
    {
    }
    //method that gets what the move entered was
    //r: right l: left d: down z: cw x: ccw
    private void moveEntered(String move)
    {
    }
    //method that gets the input from the user, looping until the user types Quie
    private void readInput()
    {
    }

    //method that prints text view of the game, refreshing after each move
    private void refreshDisplay()
    {
    }
}