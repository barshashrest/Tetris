import java.lang.Object;

// GUI version of the Tetris game.
public class TetrisGUIApplication
{
    //start the game
    public static void main(String[] args)
    {
    }
}
